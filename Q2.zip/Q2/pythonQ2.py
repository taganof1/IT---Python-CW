# open the file using the 'r' indicator meaning read and set up a variable to read the lines in a file
with open("preferences.txt", "r") as file:
    lines = file.readlines()

# split list and read numbers as intergers
    prefs = list(map(int, lines[0].split()))

# create list to store each of the prefrences for each friend
    sharedfriendprefs = []

# read over the lines for reamining friends preferences 
    for i in range(1, len(lines)):

# split the line being read to intergers
        friendpefs = list(map(int, lines[i].split()))

# find number of shared preferences each friend has by comparing the 2 lists
        sharedfriendprefs.append(len(set(prefs) & set(friendpefs)))
        
# print each friend and how many shared preferences they all have
    for i in range(len(sharedfriendprefs)):
        print(f"Friend {i + 1} shares {sharedfriendprefs[i]} preferences")