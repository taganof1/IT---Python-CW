# Open the input file in read mode
with open("preferences.txt", "r") as file:

    # Read the lines from the file
    lines = file.readlines()

    # Split the first line of the file into a list of integers
    prefs = list(map(int, lines[0].split()))

    # Initialize a list to store the number of shared preferences for each friend
    friendprefs = []

    # Iterate over the remaining lines (friends' preferences)
    for i in range(1, len(lines)):

        # Split the current line into a list of integers
        friend_preferences = list(map(int, lines[i].split()))

        # Find the number of shared preferences by using the intersection of the two lists
        friendprefs.append(len(set(prefs) & set(friendprefs)))
        
    # Print the number of shared preferences for each friend
    for i in range(len(friendprefs)):
        print(f"Friend {i + 1} shares {friendprefs[i]} preferences")