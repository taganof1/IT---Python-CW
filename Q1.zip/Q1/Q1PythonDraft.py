#Create a Loop
while True:

# Create a variable called checkPassword that asks the user to enter a password
    checkPassword = input("Enter a Password ('quit' to exit): ")

# if the user enters 'quit' the application ends
    if checkPassword == "quit":
        print("Application End")
        break

# if the password is less than 10 characters it will return with weak password
    if len(checkPassword) < 10:
        print("Error: There must be at least 10 characters in the password.")
        print("Weak Password")
        continue

# if the pasword does not have any numbers it will return with weak password
    if not any(c.isnumeric() for c in checkPassword):
        print("Error: The password must contain at least one numeric character.")
        print("Weak Password")
        continue
# if the password does not have a lowercase letter it will return with weak password
    if not any(c.islower() for c in checkPassword):
        print("Error: The password must contain at least one lowercase letter.")
        print("Weak Password")
        continue

# if the password does not have an uppercase letter it will return with weak password
    if not any(c.isupper() for c in checkPassword):
        print("Error: The password must contain at least one uppercase letter.")
        print("Weak Password")
        continue

# if all the variables are true then it will return with strong password
    print("Strong Password")